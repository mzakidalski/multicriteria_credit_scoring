
# File folder: D:\QtProjects\full_phd_application\experiments\Lending_Club_loan_acquisition
# setwd("D:/QtProjects/full_phd_application/experiments/Lending_Club_loan_acquisition_2_SETS_MULTICRITERIA_AUC_F1_ELITISM")



library(readr)
library(dplyr)
library(fastDummies)
library(caret)

#number of rows in the sum of train and test sets
RESULT_ROWS_NUMBER = 1000

#how much data goest into TRAIN set
TRAIN_SET_PERCENT = 0.6

#random generator seed
RANDOM_GENERATOR_SEED = 345612

minMaxNormalization <- function(vector, min, max) {
  return ((vector - min)/(max - min))  
}
meanSdNormalization <- function(vector, mean, sd) {
  return ((vector - mean)/sd)
}

# In each dataset we have a balanced set of classes.
# Half is paid, half is not paid.

createTrainTestIndices<-function(loans) {
  indices_paid <- which(loans$not_fully_paid == 0)
  indices_not_paid <- which(loans$not_fully_paid == 1)
  
  train_rows_num <- as.integer(RESULT_ROWS_NUMBER * TRAIN_SET_PERCENT)
  test_rows_num <- RESULT_ROWS_NUMBER - train_rows_num
  
  train_paid   <- sample(indices_paid, size = train_rows_num/2)
  train_unpaid <- sample(indices_not_paid, size = train_rows_num/2)
  train_indices <- union(train_paid, train_unpaid)
  
  indices_paid     <- setdiff(indices_paid, train_indices)
  indices_not_paid <- setdiff(indices_not_paid, train_indices)
  
  test_paid <- sample(indices_paid, size = test_rows_num/2)
  test_not_paid <- sample(indices_not_paid, size = test_rows_num/2)
  test_indices <- union(test_paid, test_not_paid)
  
  result <- list("train" = train_indices, "test" = test_indices)
}

loadAndConvertData <- function() {
  loans <- readr::read_csv("./loans.csv.gz")
  indices <- createTrainTestIndices(loans)
  trainIndex <- indices$train
  testIndex  <- indices$test
  
  #purpose - converted to factor, will be changed using dummy variable
  # TODO: second step of transformation
  loans$purpose <- as.factor(as.character(loans$purpose))
  loans <- dummy_cols(loans, select_columns = "purpose")
  loans <- loans %>% select(-purpose, -not_fully_paid, not_fully_paid)
  
  
  #credit_policy - 0 or 1 - nothing to do
  
  #int_rate is between 0.06 and 0.2164 - nothing to do
  
  #installment is between 0 and 940$ so just divide it by 1000
  loans$installment <- loans$installment / 1000.0
  
  #log_annual_inc - seems to have normal distribution, normalized to standard
  # normali distribution
  loans$log_annual_inc = meanSdNormalization(loans$log_annual_inc, 
                                             mean(loans[trainIndex,]$log_annual_inc), 
                                             sd(loans[trainIndex,]$log_annual_inc))
  
  #dti - atypical distribution with min = 0 and max = 29.960
  #    - preprocessing using min/max normalization
  loans$dti = minMaxNormalization(loans$dti, 
                                  min(loans[trainIndex,]$dti), 
                                  max(loans[trainIndex,]$dti))
  
  # FICO score - min/max normalization as FICO score must be between 300 and 850
  loans$fico <- minMaxNormalization(loans$fico, 300, 850)
  
  # days_with_cr_line - has distribution similar to t-student
  # first, log transformation is applied, then min-max normalization.
  loans <- 
    loans %>% mutate(log_days_with_cr_line = log(loans$days_with_cr_line))
  loans$days_with_cr_line <- minMaxNormalization(loans$log_days_with_cr_line, 
                                                 min(loans[trainIndex,]$log_days_with_cr_line), 
                                                 max(loans[trainIndex,]$log_days_with_cr_line))
  loans <- loans %>% select(-log_days_with_cr_line)
  
  #revol_bal - right-skewed distribution with min = 0 and max = 1 207 359
  # first - log transformation, then min-max normalization
  loans$revol_bal <- log(loans$revol_bal + 1)
  loans$revol_bal <- minMaxNormalization(loans$revol_bal, 
                                         min(loans[trainIndex,]$revol_bal), 
                                         max(loans[trainIndex,]$revol_bal))
  
  # revol_util - seems to be expressed in %, so we just divide it by 100
  #   there are about 27 values > 100 which stand for the extreme cases
  loans$revol_util <- loans$revol_util / 100.0
  
  # inq_last_6mths - left-skewed distribution with with not-so-many values(mean at
  # about 1.577, median = 1, max = 33) so we use standard min-max normalization
  loans$inq_last_6mths <- minMaxNormalization(loans$inq_last_6mths, 
                                              min(loans[trainIndex,]$inq_last_6mths),
                                              max(loans[trainIndex,]$inq_last_6mths))
  
  # delinq_2yrs divide it by 24 (maximal number of times the borrower had been 
  # 30+ past due)
  loans$delinq_2yrs <- loans$delinq_2yrs / 24.0
  
  # the borrower's number of derogatory public records - right-skewed transformation
  # standard min-max normalization
  loans$pub_rec <- minMaxNormalization(loans$pub_rec, min(loans[trainIndex,]$pub_rec), 
                                       max(loans[trainIndex,]$pub_rec))
  # not_fully_paid - 0 or 1 - nothing to do
  
  result = list("train" = loans[trainIndex,], "test" = loans[testIndex,])
  return(result)
}

saveResultData <- function(result_list) {
  train_data <- result_list$train
  test_data <- result_list$test

  readr::write_csv(train_data, "./train.data", append = FALSE, col_names = FALSE)
  readr::write_csv(train_data, "./train_with_colnames.data", append = FALSE, col_names = TRUE)
  
  readr::write_csv(test_data, "./test.data", append = FALSE, col_names = FALSE)
  readr::write_csv(test_data, "./test_with_colnames.data", append = FALSE, col_names = TRUE)
  
  readr::write_csv(rbind(train_data,test_data), "./train_test.data", append = FALSE, 
                   col_names = FALSE)
  readr::write_csv(rbind(train_data, test_data), "./train_test_with_colnames.data", 
                   append = FALSE, col_names = TRUE)
}

main <- function() {
  set.seed(RANDOM_GENERATOR_SEED)
  print("The original data has been downloaded from datacamp.com.")
  result_data <-loadAndConvertData()
  saveResultData(result_data)
  print("Finished data pre-processing.")
}

main()
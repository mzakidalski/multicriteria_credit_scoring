# Credit Approval (crx.data), distributed in the UCI Japanese Credit Screening archive.
# Numeric CSV preparation uses base R only. Run this file with Rscript or source it.
DATA_SELECTION_SEED <- 480346822L
TRAIN_SET_SIZE <- 300L
TEST_SET_SIZE <- 150L
DATASET_URL <- "https://archive.ics.uci.edu/static/public/28/japanese+credit+screening.zip"
NUMERIC_ATTRIBUTES <- c("A2", "A3", "A8", "A11", "A14", "A15")
# Fixed domains from crx.names; no categories are learned from TEST.
CATEGORY_LEVELS <- list(
  A1 = c("b", "a"), A4 = c("u", "y", "l", "t"), A5 = c("g", "p", "gg"),
  A6 = c("c", "d", "cc", "i", "j", "k", "m", "r", "q", "w", "x", "e", "aa", "ff"),
  A7 = c("v", "h", "bb", "j", "n", "z", "dd", "ff", "o"),
  A9 = c("t", "f"), A10 = c("t", "f"), A12 = c("t", "f"), A13 = c("g", "p", "s")
)

findScriptDirectory <- function() {
  frames <- sys.frames()
  for (frame in rev(frames)) {
    if (!is.null(frame$ofile)) {
      return(dirname(normalizePath(frame$ofile, mustWork = TRUE)))
    }
  }
  arguments <- commandArgs(trailingOnly = FALSE)
  fileArgument <- grep("^--file=", arguments, value = TRUE)
  if (length(fileArgument) != 1L) {
    stop("Cannot determine script directory. Use source(full_path) or Rscript full_path.")
  }
  dirname(normalizePath(sub("^--file=", "", fileArgument), mustWork = TRUE))
}

SCRIPT_DIRECTORY <- findScriptDirectory()

downloadSourceData <- function(directory) {
  archive <- tempfile(fileext = ".zip")
  on.exit(unlink(archive), add = TRUE)
  method <- if (.Platform$OS.type == "windows") "wininet" else "libcurl"
  download.file(DATASET_URL, archive, mode = "wb", method = method, quiet = TRUE)
  members <- unzip(archive, list = TRUE)$Name
  if (!all(c("crx.data", "crx.names") %in% members)) {
    stop("The UCI archive does not contain the expected Credit Approval files.")
  }
  unzip(archive, files = c("crx.data", "crx.names"), exdir = directory, overwrite = TRUE)
}

readCompleteSourceRows <- function(path) {
  raw <- read.csv(path, header = FALSE, colClasses = "character", na.strings = "?",
                  strip.white = TRUE, stringsAsFactors = FALSE)
  if (nrow(raw) != 690L || ncol(raw) != 16L) {
    stop("Unexpected source dimensions: expected 690 rows and 16 columns.")
  }
  names(raw) <- c(paste0("A", seq_len(15L)), "class")
  if (anyNA(raw$class) || !all(raw$class %in% c("+", "-"))) {
    stop("Unexpected class label: expected + or -.")
  }
  raw$source_row_id <- seq_len(nrow(raw))
  list(raw = raw, complete = raw[complete.cases(raw), , drop = FALSE])
}

encodeSourceAttributes <- function(source) {
  encoded <- data.frame(row.names = seq_len(nrow(source)))
  for (attribute in paste0("A", seq_len(15L))) {
    values <- source[[attribute]]
    if (attribute %in% NUMERIC_ATTRIBUTES) {
      numericValues <- suppressWarnings(as.numeric(values))
      if (any(!is.finite(numericValues))) {
        stop(paste("Invalid numeric values in", attribute))
      }
      encoded[[attribute]] <- numericValues
    } else {
      levels <- CATEGORY_LEVELS[[attribute]]
      if (!all(values %in% levels)) {
        stop(paste("Unknown categorical value in", attribute))
      }
      for (category in levels) {
        encoded[[paste(attribute, category, sep = "_")]] <- as.integer(values == category)
      }
    }
  }
  # Approval/refusal is the observed label, not a later repayment/default outcome.
  encoded$Y <- as.integer(source$class == "-")
  encoded
}

selectBalancedDisjointRows <- function(labels, trainSize = TRAIN_SET_SIZE, testSize = TEST_SET_SIZE,
                                       seed = DATA_SELECTION_SEED) {
  if (any(!is.finite(c(trainSize, testSize))) || trainSize < 2L || testSize < 2L ||
      trainSize %% 2L != 0L || testSize %% 2L != 0L || !all(labels %in% c(0L, 1L))) {
    stop("Require binary labels and positive even TRAIN/TEST sizes (equal sizes are allowed).")
  }
  set.seed(seed, kind = "Mersenne-Twister", normal.kind = "Inversion", sample.kind = "Rejection")
  train <- integer()
  test <- integer()
  for (label in c(0L, 1L)) {
    available <- which(labels == label)
    required <- (trainSize + testSize) / 2L
    if (length(available) < required) {
      stop(paste("Insufficient complete rows for class", label))
    }
    selected <- available[sample.int(length(available), required, replace = FALSE)]
    train <- c(train, selected[seq_len(trainSize / 2L)])
    test <- c(test, selected[seq.int(trainSize / 2L + 1L, required)])
  }
  train <- train[sample.int(length(train))]
  test <- test[sample.int(length(test))]
  if (length(intersect(train, test)) != 0L) {
    stop("TRAIN and TEST overlap.")
  }
  list(train = train, test = test)
}

fitTrainMinMax <- function(train) {
  features <- setdiff(names(train), "Y")
  minima <- vapply(train[features], min, numeric(1L))
  maxima <- vapply(train[features], max, numeric(1L))
  # Constant TRAIN columns become zero; a unit divisor preserves an unseen one-hot flag in TEST.
  divisor <- ifelse(maxima > minima, maxima - minima, 1)
  data.frame(feature = features, train_min = unname(minima), train_max = unname(maxima),
             divisor = unname(divisor), stringsAsFactors = FALSE)
}

applyTrainMinMax <- function(data, parameters) {
  result <- data
  for (index in seq_len(nrow(parameters))) {
    feature <- parameters$feature[index]
    result[[feature]] <- (data[[feature]] - parameters$train_min[index]) / parameters$divisor[index]
  }
  if (any(!is.finite(as.matrix(result)))) {
    stop("Non-finite normalized data.")
  }
  # TEST is not clipped: values outside TRAIN extrema may fall outside [0,1].
  result
}

validatePreparedSplit <- function(train, test, trainIds, testIds) {
  if (nrow(train) != TRAIN_SET_SIZE || nrow(test) != TEST_SET_SIZE ||
      ncol(train) != 48L || !identical(names(train), names(test)) ||
      anyDuplicated(trainIds) || anyDuplicated(testIds) || length(intersect(trainIds, testIds))) {
    stop("Invalid split dimensions, schema, or source-row identifiers.")
  }
  for (data in list(train, test)) {
    if (any(!is.finite(as.matrix(data))) ||
        !identical(as.integer(table(factor(data$Y, levels = c(0L, 1L)))), rep(as.integer(nrow(data) / 2L), 2L))) {
      stop("Non-numeric data or unbalanced classes.")
    }
  }
  values <- as.matrix(train[setdiff(names(train), "Y")])
  if (any(values < 0 | values > 1)) {
    stop("TRAIN min-max normalization is outside [0,1].")
  }
}

writeNumericDataFiles <- function(directory, train, test) {
  for (set in c("train", "test", "train_test")) {
    data <- switch(set, train = train, test = test, train_test = rbind(train, test))
    for (withNames in c(FALSE, TRUE)) {
      suffix <- if (withNames) "_with_colnames.data" else ".data"
      write.table(data, file.path(directory, paste0(set, suffix)), sep = ",", quote = FALSE,
                  row.names = FALSE, col.names = withNames, eol = "\n")
    }
  }
}

writePreparationAudit <- function(directory, source, selection, encoded, parameters) {
  manifest <- data.frame(source_row_id = source$raw$source_row_id, class = source$raw$class,
                         partition = "excluded_missing", output_row = NA_integer_)
  manifest$partition[source$complete$source_row_id] <- "excluded_balance"
  for (set in c("train", "test")) {
    ids <- source$complete$source_row_id[selection[[set]]]
    manifest$partition[ids] <- set
    manifest$output_row[ids] <- seq_along(ids)
  }
  write.csv(manifest, file.path(directory, "split_manifest.csv"), row.names = FALSE, na = "")
  write.csv(parameters, file.path(directory, "min_max_parameters.csv"), row.names = FALSE)
  writeLines(c(
    "Dataset: Credit Approval (crx.data), NOT the 125-person credit.lisp dataset.",
    paste("Source archive:", DATASET_URL),
    paste("Source crx.data MD5:", unname(tools::md5sum(file.path(directory, "crx.data")))),
    paste("Data selection seed:", DATA_SELECTION_SEED),
    paste("Raw rows:", nrow(source$raw)), paste("Complete rows:", nrow(source$complete)),
    paste("Excluded missing:", nrow(source$raw) - nrow(source$complete)),
    paste("Excluded for class balancing:", sum(manifest$partition == "excluded_balance")),
    paste("TRAIN rows:", TRAIN_SET_SIZE, "; each class:", TRAIN_SET_SIZE / 2L),
    paste("TEST rows:", TEST_SET_SIZE, "; each class:", TEST_SET_SIZE / 2L),
    paste("Input features:", ncol(encoded) - 1L, "; input neurons including bias:", ncol(encoded)),
    "Label: approval (+) = 0; refusal (-) = 1; positive class = 1.",
    "Categorical features: one-hot, fixed domains from crx.names; missing rows removed.",
    "Min-max parameters fitted on TRAIN ONLY; same transform on TEST; no clipping.",
    "Constant TRAIN features: divisor 1; TRAIN value 0; TEST retains differences.",
    "Source-row identifiers are audit metadata and are NOT neural-network inputs."
  ), file.path(directory, "preprocessing_summary.txt"))
}

main <- function(directory = SCRIPT_DIRECTORY, download = TRUE) {
  oldOptions <- options(digits = 17, scipen = 999)
  on.exit(options(oldOptions), add = TRUE)
  if (download) {
    downloadSourceData(directory)
  }
  source <- readCompleteSourceRows(file.path(directory, "crx.data"))
  encoded <- encodeSourceAttributes(source$complete)
  selection <- selectBalancedDisjointRows(encoded$Y)
  train <- encoded[selection$train, , drop = FALSE]
  test <- encoded[selection$test, , drop = FALSE]
  parameters <- fitTrainMinMax(train)
  train <- applyTrainMinMax(train, parameters)
  test <- applyTrainMinMax(test, parameters)
  validatePreparedSplit(train, test, source$complete$source_row_id[selection$train],
                        source$complete$source_row_id[selection$test])
  writeNumericDataFiles(directory, train, test)
  writePreparationAudit(directory, source, selection, encoded, parameters)
  cat("Prepared", directory, ":", nrow(train), "TRAIN /", nrow(test), "TEST;",
      ncol(train) - 1L, "numeric input features.\n")
  invisible(list(train = train, test = test, selection = selection, parameters = parameters))
}

if (sys.nframe() == 0L) {
  main()
}

# Loan Default Prediction, nikhil1e9/loan-default (Kaggle / Coursera).
# One-hot encoding, TRAIN-only min-max, disjoint balanced TRAIN/TEST/30 additional sets.
DATA_SELECTION_SEED <- 172903541L
TRAIN_SET_SIZE <- 300L
TEST_SET_SIZE <- 150L
ADDITIONAL_SET_SIZE <- 150L
ADDITIONAL_SET_COUNT <- 30L
DATASET_URL <- "https://www.kaggle.com/api/v1/datasets/download/nikhil1e9/loan-default"
NUMERIC_ATTRIBUTES <- c("Age", "Income", "LoanAmount", "CreditScore", "MonthsEmployed",
                         "NumCreditLines", "InterestRate", "LoanTerm", "DTIRatio")
CATEGORY_LEVELS <- list(
  Education = c("Bachelor's", "High School", "Master's", "PhD"),
  EmploymentType = c("Full-time", "Part-time", "Self-employed", "Unemployed"),
  MaritalStatus = c("Divorced", "Married", "Single"),
  HasMortgage = c("No", "Yes"), HasDependents = c("No", "Yes"),
  LoanPurpose = c("Auto", "Business", "Education", "Home", "Other"),
  HasCoSigner = c("No", "Yes")
)

findScriptDirectory <- function() {
  frames <- sys.frames()
  for (frame in rev(frames)) {
    if (!is.null(frame$ofile)) {
      return(dirname(normalizePath(frame$ofile, mustWork = TRUE)))
    }
  }
  arguments <- commandArgs(trailingOnly = FALSE)
  fileArgument <- grep("^--file=", arguments, value = TRUE)
  if (length(fileArgument) != 1L) {
    stop("Cannot determine script directory. Use source(full_path) or Rscript full_path.")
  }
  dirname(normalizePath(sub("^--file=", "", fileArgument), mustWork = TRUE))
}

SCRIPT_DIRECTORY <- findScriptDirectory()

downloadSourceData <- function(directory) {
  archive <- tempfile(fileext = ".zip")
  on.exit(unlink(archive), add = TRUE)
  method <- if (.Platform$OS.type == "windows") "wininet" else "libcurl"
  download.file(DATASET_URL, archive, mode = "wb", method = method, quiet = TRUE)
  if (!("Loan_default.csv" %in% unzip(archive, list = TRUE)$Name)) {
    stop("Expected Loan_default.csv not found in Kaggle archive.")
  }
  unzip(archive, files = "Loan_default.csv", exdir = directory, overwrite = TRUE)
}

readSourceData <- function(directory) {
  raw <- read.csv(file.path(directory, "Loan_default.csv"), stringsAsFactors = FALSE)
  expected <- c("LoanID", NUMERIC_ATTRIBUTES, names(CATEGORY_LEVELS), "Default")
  if (nrow(raw) != 255347L || !identical(names(raw), expected) || anyNA(raw) ||
      anyDuplicated(raw$LoanID) || !all(raw$Default %in% c(0L, 1L))) {
    stop("Unexpected source schema, missing values, IDs, or labels.")
  }
  raw
}

encodeSourceAttributes <- function(raw) {
  encoded <- raw[NUMERIC_ATTRIBUTES]
  for (attribute in names(CATEGORY_LEVELS)) {
    if (!all(raw[[attribute]] %in% CATEGORY_LEVELS[[attribute]])) {
      stop(paste("Unknown category in", attribute))
    }
    for (category in CATEGORY_LEVELS[[attribute]]) {
      encoded[[paste(attribute, category, sep = "_")]] <- as.integer(raw[[attribute]] == category)
    }
  }
  encoded$Y <- raw$Default
  if (any(!is.finite(as.matrix(encoded)))) stop("Non-finite source values.")
  encoded
}

selectBalancedDisjointRows <- function(labels) {
  sizes <- c(train = TRAIN_SET_SIZE, test = TEST_SET_SIZE,
             setNames(rep(ADDITIONAL_SET_SIZE, ADDITIONAL_SET_COUNT), sprintf("additional_%02d", seq_len(ADDITIONAL_SET_COUNT))))
  if (any(sizes < 2L | sizes %% 2L != 0L)) stop("Split sizes must be positive and even.")
  set.seed(DATA_SELECTION_SEED, kind = "Mersenne-Twister", normal.kind = "Inversion", sample.kind = "Rejection")
  selection <- setNames(lapply(sizes, function(size) integer()), names(sizes))
  for (label in c(0L, 1L)) {
    available <- which(labels == label)
    required <- sum(sizes) / 2L
    if (length(available) < required) stop("Insufficient class members for disjoint splits.")
    pool <- available[sample.int(length(available), required)]
    offset <- 0L
    for (name in names(sizes)) {
      count <- sizes[[name]] / 2L
      selection[[name]] <- c(selection[[name]], pool[offset + seq_len(count)])
      offset <- offset + count
    }
  }
  selection <- lapply(selection, function(ids) ids[sample.int(length(ids))])
  if (anyDuplicated(unlist(selection))) stop("Data partitions overlap.")
  selection
}

fitTrainMinMax <- function(train) {
  features <- setdiff(names(train), "Y")
  minima <- vapply(train[features], min, numeric(1L))
  maxima <- vapply(train[features], max, numeric(1L))
  # Constant TRAIN columns become zero; a unit divisor preserves an unseen one-hot flag in TEST.
  divisor <- ifelse(maxima > minima, maxima - minima, 1)
  data.frame(feature = features, train_min = unname(minima), train_max = unname(maxima),
             divisor = unname(divisor), stringsAsFactors = FALSE)
}

applyTrainMinMax <- function(data, parameters) {
  result <- data
  for (index in seq_len(nrow(parameters))) {
    feature <- parameters$feature[index]
    result[[feature]] <- (data[[feature]] - parameters$train_min[index]) / parameters$divisor[index]
  }
  if (any(!is.finite(as.matrix(result)))) {
    stop("Non-finite normalized data.")
  }
  # TEST is not clipped: values outside TRAIN extrema may fall outside [0,1].
  result
}

validatePreparedSplit <- function(data, size) {
  if (nrow(data) != size || ncol(data) != 32L || any(!is.finite(as.matrix(data))) ||
      !identical(as.integer(table(factor(data$Y, levels = c(0L, 1L)))), rep(as.integer(size / 2L), 2L))) {
    stop("Invalid split dimensions, numeric values or class balance.")
  }
}

writeNumericDataFiles <- function(directory, name, data) {
  for (withNames in c(FALSE, TRUE)) {
    suffix <- if (withNames) "_with_colnames.data" else ".data"
    write.table(data, file.path(directory, paste0(name, suffix)), sep = ",", quote = FALSE,
                row.names = FALSE, col.names = withNames, eol = "\n")
  }
}

main <- function(directory = SCRIPT_DIRECTORY, download = TRUE) {
  oldOptions <- options(digits = 17, scipen = 999)
  on.exit(options(oldOptions), add = TRUE)
  if (download) downloadSourceData(directory)
  raw <- readSourceData(directory)
  encoded <- encodeSourceAttributes(raw)
  selection <- selectBalancedDisjointRows(encoded$Y)
  parameters <- fitTrainMinMax(encoded[selection$train, , drop = FALSE])
  write.csv(parameters, file.path(directory, "min_max_parameters.csv"), row.names = FALSE)
  manifest <- data.frame(source_row_id = seq_len(nrow(raw)), LoanID = raw$LoanID,
                         class = raw$Default, partition = "unused", output_row = NA_integer_)
  for (name in names(selection)) {
    ids <- selection[[name]]
    data <- applyTrainMinMax(encoded[ids, , drop = FALSE], parameters)
    size <- if (name == "train") TRAIN_SET_SIZE else if (name == "test") TEST_SET_SIZE else ADDITIONAL_SET_SIZE
    validatePreparedSplit(data, size)
    if (name == "train" && any(as.matrix(data) < 0 | as.matrix(data) > 1)) stop("TRAIN outside [0,1].")
    writeNumericDataFiles(directory, name, data)
    manifest$partition[ids] <- name
    manifest$output_row[ids] <- seq_along(ids)
  }
  write.csv(manifest, file.path(directory, "split_manifest.csv"), row.names = FALSE, na = "")
  writeLines(c("Dataset: Loan Default Prediction, nikhil1e9/loan-default, Kaggle / Coursera.",
               paste("Source:", DATASET_URL),
               paste("Source MD5:", unname(tools::md5sum(file.path(directory, "Loan_default.csv")))),
               paste("Data selection seed:", DATA_SELECTION_SEED),
               paste("Source rows:", nrow(raw)),
               paste("Source class counts:", paste(names(table(raw$Default)), table(raw$Default), collapse = "; ")),
               "TRAIN: 300 (150 per class); TEST: 150 (75 per class).",
               "additional datasets: 30 disjoint sets, each 150 (75 per class), also disjoint from TRAIN/TEST.",
               "31 input features plus bias. LoanID excluded; Default is the output label.",
               "One-hot for all categorical levels; min-max fitted ONLY on TRAIN; TEST/additional datasets not clipped.",
               "additional datasets files are for external final assessment, not training or model selection.",
               paste("Unused rows:", sum(manifest$partition == "unused"))),
             file.path(directory, "preprocessing_summary.txt"))
  cat("Prepared TRAIN", TRAIN_SET_SIZE, "/ TEST", TEST_SET_SIZE, "/", ADDITIONAL_SET_COUNT, "additional sets of", ADDITIONAL_SET_SIZE, "rows.\n")
  invisible(selection)
}

if (sys.nframe() == 0L) main()

# Fannie Mae Single-Family Loan Performance, 2007Q1, 90+ days within 24 payment months.
# One-hot encoding, TRAIN-only min-max, disjoint balanced TRAIN/TEST/30 additional sets.
DATA_SELECTION_SEED <- 608912743L
TRAIN_SET_SIZE <- 300L
TEST_SET_SIZE <- 150L
ADDITIONAL_SET_SIZE <- 150L
ADDITIONAL_SET_COUNT <- 30L
SOURCE_ARCHIVE <- "F:/2007Q1.zip"
PYTHON_EXECUTABLE <- "C:/rtools43/mingw64/bin/python.exe"
NUMERIC_ATTRIBUTES <- c("OriginalInterestRate", "OriginalUPB", "OriginalLoanTerm", "OriginalLTV",
                         "OriginalCLTV", "NumberOfBorrowers", "DTI", "BorrowerFICO", "NumberOfUnits")
CATEGORY_LEVELS <- list(Channel = c("B", "C", "R"), FirstTimeBuyer = c("N", "Y", "Unknown"),
                        LoanPurpose = c("C", "P", "R", "U"),
                        PropertyType = c("CO", "CP", "MH", "PU", "SF"),
                        Occupancy = c("I", "P", "S", "U"))

findScriptDirectory <- function() {
  frames <- sys.frames()
  for (frame in rev(frames)) {
    if (!is.null(frame$ofile)) {
      return(dirname(normalizePath(frame$ofile, mustWork = TRUE)))
    }
  }
  arguments <- commandArgs(trailingOnly = FALSE)
  fileArgument <- grep("^--file=", arguments, value = TRUE)
  if (length(fileArgument) != 1L) {
    stop("Cannot determine script directory. Use source(full_path) or Rscript full_path.")
  }
  dirname(normalizePath(sub("^--file=", "", fileArgument), mustWork = TRUE))
}

SCRIPT_DIRECTORY <- findScriptDirectory()

prepareSourceData <- function(directory) {
  if (!file.exists(SOURCE_ARCHIVE)) stop("Set SOURCE_ARCHIVE to your downloaded Fannie Mae ZIP.")
  if (!file.exists(PYTHON_EXECUTABLE)) stop("Set PYTHON_EXECUTABLE to Python 3.11 or newer.")
  status <- system2(PYTHON_EXECUTABLE, c(shQuote(file.path(directory, "prepare_source.py")), shQuote(SOURCE_ARCHIVE)))
  if (status != 0L) stop("Fannie Mae source aggregation failed.")
}

readSourceData <- function(directory) {
  raw <- read.csv(file.path(directory, "eligible_loans.csv"), colClasses = "character", stringsAsFactors = FALSE)
  if (anyDuplicated(raw$loan_id) || !all(raw$Y %in% c("0", "1")) ||
      !all(c(NUMERIC_ATTRIBUTES, names(CATEGORY_LEVELS)) %in% names(raw))) stop("Invalid aggregated loan schema.")
  for (name in NUMERIC_ATTRIBUTES) raw[[name]] <- as.numeric(raw[[name]])
  raw$Y <- as.integer(raw$Y)
  raw
}

encodeSourceAttributes <- function(raw) {
  encoded <- raw[NUMERIC_ATTRIBUTES]
  for (attribute in names(CATEGORY_LEVELS)) {
    if (!all(raw[[attribute]] %in% CATEGORY_LEVELS[[attribute]])) {
      stop(paste("Unknown category in", attribute))
    }
    for (category in CATEGORY_LEVELS[[attribute]]) {
      encoded[[paste(attribute, category, sep = "_")]] <- as.integer(raw[[attribute]] == category)
    }
  }
  encoded$Y <- raw$Y
  if (any(!is.finite(as.matrix(encoded)))) stop("Non-finite source values.")
  encoded
}

selectBalancedDisjointRows <- function(labels) {
  sizes <- c(train = TRAIN_SET_SIZE, test = TEST_SET_SIZE,
             setNames(rep(ADDITIONAL_SET_SIZE, ADDITIONAL_SET_COUNT), sprintf("additional_%02d", seq_len(ADDITIONAL_SET_COUNT))))
  if (any(sizes < 2L | sizes %% 2L != 0L)) stop("Split sizes must be positive and even.")
  set.seed(DATA_SELECTION_SEED, kind = "Mersenne-Twister", normal.kind = "Inversion", sample.kind = "Rejection")
  selection <- setNames(lapply(sizes, function(size) integer()), names(sizes))
  for (label in c(0L, 1L)) {
    available <- which(labels == label)
    required <- sum(sizes) / 2L
    if (length(available) < required) stop("Insufficient class members for disjoint splits.")
    pool <- available[sample.int(length(available), required)]
    offset <- 0L
    for (name in names(sizes)) {
      count <- sizes[[name]] / 2L
      selection[[name]] <- c(selection[[name]], pool[offset + seq_len(count)])
      offset <- offset + count
    }
  }
  selection <- lapply(selection, function(ids) ids[sample.int(length(ids))])
  if (anyDuplicated(unlist(selection))) stop("Data partitions overlap.")
  selection
}

fitTrainMinMax <- function(train) {
  features <- setdiff(names(train), "Y")
  minima <- vapply(train[features], min, numeric(1L))
  maxima <- vapply(train[features], max, numeric(1L))
  # Constant TRAIN columns become zero; a unit divisor preserves an unseen one-hot flag in TEST.
  divisor <- ifelse(maxima > minima, maxima - minima, 1)
  data.frame(feature = features, train_min = unname(minima), train_max = unname(maxima),
             divisor = unname(divisor), stringsAsFactors = FALSE)
}

applyTrainMinMax <- function(data, parameters) {
  result <- data
  for (index in seq_len(nrow(parameters))) {
    feature <- parameters$feature[index]
    result[[feature]] <- (data[[feature]] - parameters$train_min[index]) / parameters$divisor[index]
  }
  if (any(!is.finite(as.matrix(result)))) {
    stop("Non-finite normalized data.")
  }
  # TEST is not clipped: values outside TRAIN extrema may fall outside [0,1].
  result
}

validatePreparedSplit <- function(data, size) {
  if (nrow(data) != size || ncol(data) != 29L || any(!is.finite(as.matrix(data))) ||
      !identical(as.integer(table(factor(data$Y, levels = c(0L, 1L)))), rep(as.integer(size / 2L), 2L))) {
    stop("Invalid split dimensions, numeric values or class balance.")
  }
}

writeNumericDataFiles <- function(directory, name, data) {
  for (withNames in c(FALSE, TRUE)) {
    suffix <- if (withNames) "_with_colnames.data" else ".data"
    write.table(data, file.path(directory, paste0(name, suffix)), sep = ",", quote = FALSE,
                row.names = FALSE, col.names = withNames, eol = "\n")
  }
}

main <- function(directory = SCRIPT_DIRECTORY, prepareSource = TRUE) {
  oldOptions <- options(digits = 17, scipen = 999)
  on.exit(options(oldOptions), add = TRUE)
  if (prepareSource) prepareSourceData(directory)
  raw <- readSourceData(directory)
  encoded <- encodeSourceAttributes(raw)
  selection <- selectBalancedDisjointRows(encoded$Y)
  parameters <- fitTrainMinMax(encoded[selection$train, , drop = FALSE])
  write.csv(parameters, file.path(directory, "min_max_parameters.csv"), row.names = FALSE)
  manifest <- data.frame(source_row_id = seq_len(nrow(raw)), loan_id = raw$loan_id,
                         class = raw$Y, partition = "unused", output_row = NA_integer_)
  for (name in names(selection)) {
    ids <- selection[[name]]
    data <- applyTrainMinMax(encoded[ids, , drop = FALSE], parameters)
    size <- if (name == "train") TRAIN_SET_SIZE else if (name == "test") TEST_SET_SIZE else ADDITIONAL_SET_SIZE
    validatePreparedSplit(data, size)
    if (name == "train" && any(as.matrix(data) < 0 | as.matrix(data) > 1)) stop("TRAIN outside [0,1].")
    writeNumericDataFiles(directory, name, data)
    manifest$partition[ids] <- name
    manifest$output_row[ids] <- seq_along(ids)
  }
  write.csv(manifest, file.path(directory, "split_manifest.csv"), row.names = FALSE, na = "")
  writeLines(c("Dataset: Fannie Mae Single-Family Loan Performance, 2007Q1.",
               paste("Source archive:", SOURCE_ARCHIVE),
               paste("Source MD5:", unname(tools::md5sum(file.path(directory, "eligible_loans.csv")))),
               paste("Data selection seed:", DATA_SELECTION_SEED),
               paste("Source rows:", nrow(raw)),
               paste("Source class counts:", paste(names(table(raw$Y)), table(raw$Y), collapse = "; ")),
               "TRAIN: 300 (150 per class); TEST: 150 (75 per class).",
               "additional datasets: 30 disjoint sets, each 150 (75 per class), also disjoint from TRAIN/TEST.",
               "28 input features plus bias. Loan identifier and outcome audit fields excluded from inputs.",
               "One-hot for all categorical levels; min-max fitted ONLY on TRAIN; TEST/additional datasets not clipped.",
               "Target: 90+ days delinquency within first 24 payment months; fully observed negatives only.",
               "additional datasets files are for external final assessment, not training or model selection.",
               paste("Unused rows:", sum(manifest$partition == "unused"))),
             file.path(directory, "preprocessing_summary.txt"))
  cat("Prepared TRAIN", TRAIN_SET_SIZE, "/ TEST", TEST_SET_SIZE, "/", ADDITIONAL_SET_COUNT, "additional sets of", ADDITIONAL_SET_SIZE, "rows.\n")
  invisible(selection)
}

if (sys.nframe() == 0L) main()

"""Stream official Fannie Mae quarterly ZIP into one eligible row per loan.
Usage: python prepare_source.py F:/2007Q1.zip
No extraction or modification of the source archive. Run from any directory.
"""
from pathlib import Path
import csv,zipfile,io,json,collections,hashlib,argparse,math
NUMERIC={'OriginalInterestRate':8,'OriginalUPB':10,'OriginalLoanTerm':13,'OriginalLTV':20,'OriginalCLTV':21,'NumberOfBorrowers':22,'DTI':23,'BorrowerFICO':24,'NumberOfUnits':29}
CATEGORICAL={'Channel':(4,['B','C','R']),'FirstTimeBuyer':(26,['N','Y','Unknown']),'LoanPurpose':(27,['C','P','R','U']),'PropertyType':(28,['CO','CP','MH','PU','SF']),'Occupancy':(30,['I','P','S','U'])}
def month(value):
    if len(value)!=6 or not value.isdigit() or not 1<=int(value[:2])<=12:raise ValueError('Invalid MMYYYY: '+value)
    return int(value[2:])*12+int(value[:2])-1
def classify(first,known,event_month):
    first_payment=month(first[14])
    if month(first[2])>first_payment:return None,'late_entry'
    if event_month is not None:return 1,'event_90plus_24m'
    if known==(1<<24)-1:return 0,'fully_observed_non_event'
    return None,'incomplete_or_unknown_followup'
def origination_features(first):
    result={}
    for name,pos in NUMERIC.items():
        try:value=float(first[pos-1])
        except ValueError:return None
        if not math.isfinite(value):return None
        result[name]=value
    if not 300<=result['BorrowerFICO']<=850 or not 1<=result['NumberOfUnits']<=4:return None
    if result['OriginalInterestRate']<=0 or result['OriginalUPB']<=0 or result['OriginalLoanTerm']<=0:return None
    if not 0<=result['DTI']<=100 or result['NumberOfBorrowers']<1:return None
    if result['OriginalLTV']<=0 or result['OriginalCLTV']<=0:return None
    for name,(pos,domain) in CATEGORICAL.items():
        value=first[pos-1]
        if name=='FirstTimeBuyer' and value=='':value='Unknown'
        if value not in domain:return None
        result[name]=value
    return result

def prepare(archive,output):
    reasons=collections.Counter();classes=collections.Counter();total_rows=0;seen=set();last_id=None
    first=None;known=0;event=None;previous_month=None;months_seen=set()
    header=['loan_id']+list(NUMERIC)+list(CATEGORICAL)+['Y','first_payment','first_reporting','event_month','known_month_mask']
    with zipfile.ZipFile(archive) as z,(output/'eligible_loans.csv').open('w',newline='') as destination:
        members=[x for x in z.namelist() if x.lower().endswith('.csv')]
        if len(members)!=1:raise ValueError('Expected one combined quarterly CSV')
        writer=csv.DictWriter(destination,fieldnames=header);writer.writeheader()
        def finish():
            if first is None:return
            label,reason=classify(first,known,event)
            reasons[reason]+=1
            if label is None:return
            features=origination_features(first)
            if features is None:reasons['excluded_missing_or_invalid_origination_features']+=1;return
            classes[label]+=1
            writer.writerow(dict(loan_id=first[1],**features,Y=label,first_payment=first[14],first_reporting=first[2],event_month='' if event is None else event,known_month_mask=known))
        with z.open(members[0]) as raw:
            for line in io.TextIOWrapper(raw,encoding='utf-8-sig',newline=''):
                row=line.rstrip('\r\n').split('|');total_rows+=1
                if len(row)!=114:raise ValueError('Unexpected layout: '+str(len(row)))
                loan=row[1];reporting=month(row[2])
                if loan!=last_id:
                    finish()
                    if loan in seen:raise ValueError('Loan records are not contiguous')
                    seen.add(loan);first=row;known=0;event=None;previous_month=None;months_seen=set();last_id=loan
                    if len(seen)%50000==0:print('Processed loans',len(seen),'monthly rows',total_rows,flush=True)
                if previous_month is not None and reporting<=previous_month:raise ValueError('Duplicate or unsorted monthly observations')
                previous_month=reporting
                offset=reporting-month(first[14]);status=row[39]
                if 0<=offset<24 and status.isdigit() and 0<=int(status)<=99:
                    known|=1<<offset
                    if int(status)>=3:event=reporting if event is None else min(event,reporting)
            finish()
    with archive.open('rb') as source:
        sha=hashlib.file_digest(source,'sha256').hexdigest()
    audit=dict(source_archive=str(archive.resolve()),archive_sha256=sha,source_member=members[0],layout_fields=114,monthly_rows=total_rows,unique_loans=len(seen),reasons=dict(reasons),eligible_classes=dict(classes),target='status>=3 in reporting months first_payment through first_payment+23 inclusive',negative_rule='all 24 monthly statuses observed, numeric and <3; early termination without full observation excluded',late_entry_rule='first report after first payment excluded for both labels',feature_rule='origination fields from first reported row only; missing/invalid selected numeric features excluded',numeric_positions=NUMERIC,categorical_positions_and_domains=CATEGORICAL)
    (output/'source_audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2),flush=True)
    if min(classes.get(0,0),classes.get(1,0))<2475:raise ValueError('Not enough loans for all balanced splits')
    return audit
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('archive',type=Path);args=parser.parse_args()
    prepare(args.archive,Path(__file__).resolve().parent)

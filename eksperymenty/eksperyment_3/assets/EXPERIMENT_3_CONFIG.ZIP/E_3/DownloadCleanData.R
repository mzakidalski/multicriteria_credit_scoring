library(caret)
library(Boruta)
library(glmulti)
library(dplyr)
library(tidyr)

setClass("dataPartition", representation(train_set = "data.frame", test_set = "data.frame", validate_set = "data.frame"))

downloadAndFormatDataset<-function() {
  #reading data
  url <- "https://archive.ics.uci.edu/ml/machine-learning-databases/statlog/german/german.data"
  
  #setting column names
  creditOriginalData <- read.csv(url, header <- FALSE, sep <- " ");
  colnames(creditOriginalData) <- c("status_checking_account", "duration", "credit_history", "purpose", 
                                    "credit_amount", "savings_account_bonds", "present_employment_since", 
                                    "installment_rate_in_percentage_income", "personal_status_and_sex", 
                                    "other_debtors_guarantors", "present_residence_since", "property", 
                                    "age", "other_installment_plans", "housing", "number_of_existing_credits_bank", 
                                    "job", "number_of_liable_people", "telephone", "foreign_worker", "Y")
  
  #setting qualitative columns as factors
  factor_cols <- c(1,3,4,6,7,9,10,12,14,15,16,17,19,20,21)
  numeric_cols <-c(2,5,8,11,13, 16,18) 
  for(i in factor_cols) 
    creditOriginalData[,i]<-as.factor(as.character(creditOriginalData[,i]))
  for(i in numeric_cols) 
    creditOriginalData[,i]<-as.numeric(creditOriginalData[,i])
  

  creditOriginalData;
}

# Train fraction - how much data (from 0 to 1) goes into train set
partitionDataset<-function(data, trainFraction) {

  train_index <- createDataPartition(data$Y, p = trainFraction, list = FALSE, times = 1)
  train_set <- data[train_index,]
  test_set <- data[-train_index,]
  
  new("dataPartition", train_set = train_set, test_set = test_set)
}

# Train fraction - how much data (from 0 to 1) goes into train set
partitionDatasetTwo<-function(data, trainFraction) {
  
  credit_worthy_indices <- which(data$Y == factor(1, levels=c(1,2)))
  credit_unworthy_indices <- which(data$Y == factor(2, levels=c(1,2)))
  
  train_index <- sample(credit_unworthy_indices, size = 200)
  test_index <- setdiff(credit_unworthy_indices, train_index)
  
  train_other_indices <- sample(credit_worthy_indices, 200)
  test_other_indices <- setdiff(credit_worthy_indices, train_other_indices)
  test_other_indices <- sample(train_other_indices, 100)
  
  train_index <- c(train_index, train_other_indices)
  test_index <- c(test_index, test_other_indices)
    
  train_set <- data[train_index,]
  test_set <- data[test_index,]
  
  new("dataPartition", train_set = train_set, test_set = test_set)
}

normalize <- function(df, mins, maxs) {
  result <- df # make a copy of the input data frame
  
  
  for (j in 1:ncol(result)) { # each specified col
    minimum <- mins[[j]]
    maximum <- maxs[[j]]
    
    for (i in 1:nrow(result)) { # each row of cur col
      result[i,j] <- (result[i,j] - minimum) / (maximum - minimum)
    }
  }
  return(result)
}



normalizeDataset <- function(partitionDataset) {
  partitionDataset@train_set[] <- lapply(partitionDataset@train_set, function(x) as.numeric(x))
  partitionDataset@test_set[] <- lapply(partitionDataset@test_set, function(x) as.numeric(x))

  mins <- lapply(partitionDataset@train_set, function(x) min(x, na.rm = TRUE))
  maxs <- lapply(partitionDataset@train_set, function(x) max(x, na.rm = TRUE))
  
  train_set_normalized <- normalize(partitionDataset@train_set, mins, maxs)
  test_set_normalized <- normalize(partitionDataset@test_set, mins, maxs)

  result <- new("dataPartition", train_set = train_set_normalized, test_set = test_set_normalized)
  return(result)
}

oneHotEncoding<-function(originalDataset, cols_for_encoding) {
 
  for (col_name in cols_for_encoding)  {
    originalDataset$one <- 1
    
    originalDataset <- pivot_wider(originalDataset, 
                          names_from=!!sym(col_name), 
                          values_from=one, 
                          values_fill= list(one=0),
                          names_prefix=paste0(col_name,"_"))
    
    originalDataset <- originalDataset %>% select(-Y, Y)
    
  }
  return(originalDataset)
}

main<-function() {
  rm(list = ls())
  seed <- 2357
  print(paste0("->> Setting random seed to: ", seed))
  set.seed(seed)
  
  #loading data
  print("->> Loading data from UCI repository (new version)")
  originalDataset <- downloadAndFormatDataset()
  
  print("->> one-hot encoding of selected variables")
  cols_for_encoding <- c("status_checking_account", "credit_history", 
                         "savings_account_bonds", 
                         "other_debtors_guarantors", 
                         "housing")
  
  originalDataset <- oneHotEncoding(originalDataset, cols_for_encoding)
  
  
  print("->> Partitioning data into: train and test")
  partitionDataset <- partitionDatasetTwo(originalDataset, 0.7)
  
  #normalization and writing to file
  print("->> min-max normalization and writing data to files")
  normPartitionDataset <- normalizeDataset(partitionDataset)

  print("->> writing data to file")
  
  for (fileName in c("train.data","test.data","validate.data","train_test.data",
                     "train_with_colnames.data","test_with_colnames.data","validate_with_colnames.data",
                     "train_test_with_colnames.data"))
  {
    if (file.exists(fileName)) {
      file.remove(fileName)
    }
  }
  
  write.table(normPartitionDataset@train_set, "train.data", sep=",", append=TRUE, eol="\n", row.names = FALSE, col.names = FALSE)
  write.table(normPartitionDataset@train_set, "train_with_colnames.data", sep=",", append=TRUE, eol="\n", row.names = FALSE, col.names = TRUE)
  
  write.table(normPartitionDataset@test_set, "test.data", sep=",", append=TRUE, eol="\n", row.names = FALSE, col.names = FALSE)
  write.table(normPartitionDataset@test_set, "test_with_colnames.data", sep=",", append=TRUE, eol="\n", row.names = FALSE, col.names = TRUE)
  
  train_test_normalized <- rbind(normPartitionDataset@train_set, normPartitionDataset@test_set)
  
  write.table(train_test_normalized, "train_test.data", sep=",", append=TRUE, eol="\n", row.names = FALSE, col.names = FALSE)
  write.table(train_test_normalized, "train_test_with_colnames.data", sep=",", append=TRUE, eol="\n", row.names = FALSE, col.names = TRUE)
  
  print("->> script has successfully finished")
}

main()

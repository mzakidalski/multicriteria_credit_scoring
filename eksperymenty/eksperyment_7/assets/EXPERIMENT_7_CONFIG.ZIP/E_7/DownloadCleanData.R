library(caret)
library(Boruta)
library(glmulti)
library(dplyr)
library(tidyr)

setClass(
  "dataPartition",
  representation(
    train_set = "data.frame",
    test_set = "data.frame"
  )
)

downloadAndFormatDataset <- function() {
  url <- "http://archive.ics.uci.edu/ml/machine-learning-databases/statlog/german/german.data"

  creditOriginalData <- read.csv(url, header = FALSE, sep = " ")

  colnames(creditOriginalData) <- c(
    "status_checking_account",
    "duration",
    "credit_history",
    "purpose",
    "credit_amount",
    "savings_account_bonds",
    "present_employment_since",
    "installment_rate_in_percentage_income",
    "personal_status_and_sex",
    "other_debtors_guarantors",
    "present_residence_since",
    "property",
    "age",
    "other_installment_plans",
    "housing",
    "number_of_existing_credits_bank",
    "job",
    "number_of_liable_people",
    "telephone",
    "foreign_worker",
    "Y"
  )

  factor_cols <- c(1, 3, 4, 6, 7, 9, 10, 12, 14, 15, 16, 17, 19, 20, 21)
  numeric_cols <- c(2, 5, 8, 11, 13, 16, 18)

  for (i in factor_cols) {
    creditOriginalData[, i] <- as.factor(as.character(creditOriginalData[, i]))
  }

  for (i in numeric_cols) {
    creditOriginalData[, i] <- as.numeric(creditOriginalData[, i])
  }

  return(creditOriginalData)
}

partitionDatasetIntoBalancedTrainAndTest <- function(data) {

  # Assumption for German Credit Data:
  # Y = 1 -> creditworthy / wiarygodny
  # Y = 2 -> credit-unworthy / niewiarygodny

  credit_worthy_indices <- which(data$Y == factor(1, levels = c(1, 2)))
  credit_unworthy_indices <- which(data$Y == factor(2, levels = c(1, 2)))

  n_worthy <- length(credit_worthy_indices)
  n_unworthy <- length(credit_unworthy_indices)

  print(paste0("Liczba przypadkow wiarygodnych: ", n_worthy))
  print(paste0("Liczba przypadkow niewiarygodnych: ", n_unworthy))

  if (n_unworthy < 2) {
    stop("Za malo przypadkow niewiarygodnych, aby utworzyc train_set i test_set.")
  }

  if (n_unworthy %% 2 != 0) {
    stop("Liczba przypadkow niewiarygodnych nie jest parzysta. Nie da sie podzielic ich dokladnie po polowie.")
  }

  if (n_worthy < n_unworthy) {
    stop("Za malo przypadkow wiarygodnych, aby oba zbiory byly zrownowazone.")
  }

  half_unworthy <- n_unworthy / 2

  # Random shuffle within each class
  shuffled_unworthy_indices <- sample(credit_unworthy_indices, size = n_unworthy)
  shuffled_worthy_indices <- sample(credit_worthy_indices, size = n_worthy)

  # Train receives half of all unworthy cases
  train_unworthy_indices <- shuffled_unworthy_indices[1:half_unworthy]

  # Test receives the second half of all unworthy cases
  test_unworthy_indices <- shuffled_unworthy_indices[(half_unworthy + 1):n_unworthy]

  # Add the same number of worthy cases to train
  train_worthy_indices <- shuffled_worthy_indices[1:half_unworthy]

  # Add the same number of worthy cases to test
  test_worthy_indices <- shuffled_worthy_indices[(half_unworthy + 1):(2 * half_unworthy)]

  train_index <- c(train_unworthy_indices, train_worthy_indices)
  test_index <- c(test_unworthy_indices, test_worthy_indices)

  # Shuffle rows inside final sets so that classes are not grouped
  train_index <- sample(train_index, size = length(train_index))
  test_index <- sample(test_index, size = length(test_index))

  train_set <- data[train_index, ]
  test_set <- data[test_index, ]

  # Safety check: train and test must be disjoint
  if (length(intersect(train_index, test_index)) != 0) {
    stop("Blad: train_set i test_set maja wspolne obserwacje.")
  }

  # Safety check: both sets must be balanced
  train_class_table <- table(train_set$Y)
  test_class_table <- table(test_set$Y)

  print("Rozklad klas w train_set:")
  print(train_class_table)

  print("Rozklad klas w test_set:")
  print(test_class_table)

  if (train_class_table[["1"]] != train_class_table[["2"]]) {
    stop("Blad: train_set nie jest zrownowazony.")
  }

  if (test_class_table[["1"]] != test_class_table[["2"]]) {
    stop("Blad: test_set nie jest zrownowazony.")
  }

  print(paste0("Liczba obserwacji train_set: ", nrow(train_set)))
  print(paste0("Liczba obserwacji test_set: ", nrow(test_set)))

  unused_indices <- setdiff(seq_len(nrow(data)), c(train_index, test_index))
  print(paste0("Liczba niewykorzystanych obserwacji: ", length(unused_indices)))

  return(
    new(
      "dataPartition",
      train_set = train_set,
      test_set = test_set
    )
  )
}

normalize <- function(df, mins, maxs) {
  result <- df

  for (j in 1:ncol(result)) {
    minimum <- mins[[j]]
    maximum <- maxs[[j]]

    for (i in 1:nrow(result)) {
      if (maximum == minimum) {
        result[i, j] <- 0
      } else {
        result[i, j] <- (result[i, j] - minimum) / (maximum - minimum)
      }
    }
  }

  return(result)
}

normalizeDataset <- function(partitionDataset) {

  partitionDataset@train_set[] <- lapply(partitionDataset@train_set, function(x) as.numeric(x))
  partitionDataset@test_set[] <- lapply(partitionDataset@test_set, function(x) as.numeric(x))

  mins <- lapply(partitionDataset@train_set, function(x) min(x, na.rm = TRUE))
  maxs <- lapply(partitionDataset@train_set, function(x) max(x, na.rm = TRUE))

  train_set_normalized <- normalize(partitionDataset@train_set, mins, maxs)
  test_set_normalized <- normalize(partitionDataset@test_set, mins, maxs)

  result <- new(
    "dataPartition",
    train_set = train_set_normalized,
    test_set = test_set_normalized
  )

  return(result)
}

oneHotEncoding <- function(originalDataset, cols_for_encoding) {

  for (col_name in cols_for_encoding) {
    originalDataset$one <- 1

    originalDataset <- pivot_wider(
      originalDataset,
      names_from = !!sym(col_name),
      values_from = one,
      values_fill = list(one = 0),
      names_prefix = paste0(col_name, "_")
    )

    originalDataset <- originalDataset %>% select(-Y, Y)
  }

  return(originalDataset)
}

main <- function() {
  rm(list = ls())

  seed <- 1543
  print(paste0("->> Setting random seed to: ", seed))
  set.seed(seed)

  print("->> Loading data from UCI repository")
  originalDataset <- downloadAndFormatDataset()

  print("->> One-hot encoding of selected variables")
  cols_for_encoding <- c(
    "status_checking_account",
    "credit_history",
    "savings_account_bonds",
    "other_debtors_guarantors",
    "housing"
  )

  originalDataset <- oneHotEncoding(originalDataset, cols_for_encoding)

  print("->> Partitioning data into balanced train and test sets")
  partitionDataset <- partitionDatasetIntoBalancedTrainAndTest(originalDataset)

  print("->> Min-max normalization")
  normPartitionDataset <- normalizeDataset(partitionDataset)

  print("->> Removing old output files")

  for (fileName in c(
    "train.data",
    "test.data",
    "train_test.data",
    "train_with_colnames.data",
    "test_with_colnames.data",
    "train_test_with_colnames.data"
  )) {
    if (file.exists(fileName)) {
      file.remove(fileName)
    }
  }

  print("->> Writing train and test files")

  write.table(
    normPartitionDataset@train_set,
    "train.data",
    sep = ",",
    append = TRUE,
    eol = "\n",
    row.names = FALSE,
    col.names = FALSE
  )

  write.table(
    normPartitionDataset@train_set,
    "train_with_colnames.data",
    sep = ",",
    append = TRUE,
    eol = "\n",
    row.names = FALSE,
    col.names = TRUE
  )

  write.table(
    normPartitionDataset@test_set,
    "test.data",
    sep = ",",
    append = TRUE,
    eol = "\n",
    row.names = FALSE,
    col.names = FALSE
  )

  write.table(
    normPartitionDataset@test_set,
    "test_with_colnames.data",
    sep = ",",
    append = TRUE,
    eol = "\n",
    row.names = FALSE,
    col.names = TRUE
  )

  train_test_normalized <- rbind(
    normPartitionDataset@train_set,
    normPartitionDataset@test_set
  )

  write.table(
    train_test_normalized,
    "train_test.data",
    sep = ",",
    append = TRUE,
    eol = "\n",
    row.names = FALSE,
    col.names = FALSE
  )

  write.table(
    train_test_normalized,
    "train_test_with_colnames.data",
    sep = ",",
    append = TRUE,
    eol = "\n",
    row.names = FALSE,
    col.names = TRUE
  )

  print("->> Script has successfully finished")
}

main()

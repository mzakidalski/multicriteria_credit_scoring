#included libraries
library(readr)
library(dplyr)
library(tidyr)

#global settings
# number of test cases used for the whole set
whole_set_size <- 2000
# percentage for train set
train_set_percentage <- 0.75


loadOriginalDataSet <- function() {
  print("Data originally downloaded from https://www.kaggle.com/c/GiveMeSomeCredit/data")
  result <- read_csv("cs-training.csv")
  return(result)
}

modifyColumnValues <- function(original_data) {
  result_data <- original_data %>% 
                 # RowId is removed  
                 # select(-RowId) %>%
                 # RevolvingUtilizationOfUnsecuredLines is expressed in percents so it is recalculated to
                 # fractions
                 mutate(RevolvingUtilizationOfUnsecuredLines = RevolvingUtilizationOfUnsecuredLines / 100.0) %>%
                 # age is divided by the usually maximal age
                 mutate (age = age / 100.0) %>%
                 # NumberOfTime30-59DaysPastDueNotWorse is divided by 180 (0.5 year in days)
                 mutate (`NumberOfTime30-59DaysPastDueNotWorse` = `NumberOfTime30-59DaysPastDueNotWorse` / 180.0) %>%
                 #DebtRatio is expressed in percents so we divide it by 100
                 mutate(DebtRatio = DebtRatio / 100.0) %>%
                 # MonthlyIncome:
                 #    - add column is_income_specified <- !is.na(MonthlyIncome)
                 #    - replace MonthlyIncome NAs with zeroes
                 #    - divide MonthlyIncome by 100 000 $
                 mutate(is_income_specified = as.numeric(!is.na(MonthlyIncome))) %>%
                 mutate(MonthlyIncome = replace_na(MonthlyIncome, 0)/100000.0) %>%
                 # NumberOfOpenCreditLinesAndLoans is divided by 100
                 mutate(NumberOfOpenCreditLinesAndLoans = NumberOfOpenCreditLinesAndLoans/100.0) %>%
                 # NumberOfTimes90DaysLate is divided by 180 (days of 0.5 years)
                 mutate(NumberOfTimes90DaysLate = NumberOfTimes90DaysLate / 180.0) %>%
                 # NumberRealEstateLoansOrLines is divided by 100 
                 mutate(NumberRealEstateLoansOrLines = NumberRealEstateLoansOrLines / 100.0) %>%
                 # NumberOfTime60-89DaysPastDueNotWorse is divided by 180
                 mutate(`NumberOfTime60-89DaysPastDueNotWorse` = `NumberOfTime60-89DaysPastDueNotWorse`/180.0) %>%
                 # NumberOfDependents:
                 #    - is_number_of_dependants_specified adde if this column is not NA
                 #    - replace NAs with zero
                 #    - divide this column by 50
                 mutate(is_number_of_dependants_specified = as.numeric(!is.na(NumberOfDependents))) %>% 
                 mutate(NumberOfDependents = replace_na(NumberOfDependents, 0) / 50.0) %>%
                 # SeriousDlqin2yrs is moved at the end of the data frame
                 relocate(SeriousDlqin2yrs, .after = last_col())
  
  return(result_data)
}

divideIntoTrainTestDataSets<-function(modified_data) {
  positive_modified_data <- modified_data %>% filter(SeriousDlqin2yrs == 1.0)
  negative_modified_data <- modified_data %>% filter(SeriousDlqin2yrs == 0.0)
  
  train_set_half_size <- 0.5 * whole_set_size * train_set_percentage
  train_set_positive_indexes <- sample(positive_modified_data$RowId, train_set_half_size)
  train_set_negative_indexes <- sample(negative_modified_data$RowId, train_set_half_size)
  
  train_set <- modified_data %>% filter(RowId %in% union(train_set_positive_indexes, train_set_negative_indexes))
  
  positive_modified_data <- positive_modified_data %>% filter( !(RowId %in% train_set_positive_indexes) )
  negative_modified_data <- negative_modified_data %>% filter( !(RowId %in% train_set_negative_indexes) )
  
  test_set_half_size <- 0.5 * whole_set_size *(1 - train_set_percentage)
  test_set_positive_indexes <- sample(positive_modified_data$RowId, test_set_half_size)
  test_set_negative_indexes <- sample(negative_modified_data$RowId, test_set_half_size)
  
  test_set <- modified_data %>% filter(RowId %in% union(test_set_positive_indexes, test_set_negative_indexes))
  
  print("Removing RowId")
  train_set <- train_set %>% select(-RowId)
  test_set <- test_set %>% select(-RowId)
  
  print("Saving data to csv files.")
  original_option <- getOption("scipen")
  options("scipen"=500)
  write.table(train_set, "train.data", col.names = FALSE, sep=",", append = FALSE, row.names = FALSE)
  write.table(train_set, "train_with_colnames.data", col.names = TRUE, sep=",", append = FALSE, row.names = FALSE)
  
  write.table(test_set, "test.data", col.names = FALSE, sep=",", append = FALSE, row.names = FALSE)
  write.table(test_set, "test_with_colnames.data", col.names = TRUE, sep=",", append = FALSE, row.names = FALSE)
  options("scipen" =  original_option)
  
  print("")
}


main <- function() {
  set.seed(89235)
  print("1. Loading original data")
  original_data <- loadOriginalDataSet()
  print("2. Normalizing data in original dataframe")
  modified_data <- modifyColumnValues(original_data)
  
  print("3. Dividing data into train & test set")
  divideIntoTrainTestDataSets(modified_data)
}

main()